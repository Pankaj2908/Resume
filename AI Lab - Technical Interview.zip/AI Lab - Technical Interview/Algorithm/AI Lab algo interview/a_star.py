# Finish A* search function that can find path from starting point to the end
# The robot starts from start position (0,0) and finds a path to end position (4, 5)
# In the maze, 0 is open path while 1 means wall (a robot cannot pass through wall)
# please write your heuristic matrix, and fill unvisited position with -1,
# cost of each movement is 1, as shown in the example below

# example result:
# [[0, -1, -1, -1, -1, -1],
#  [1, -1, -1, -1, -1, -1],
#  [2, -1, -1, -1, -1, -1],
#  [3, -1,  8, 10, 12, 14],
#  [4,  5,  6,  7, -1, 15]]

# the maze robot need to find a path
maze = [[0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 1, 0]]

start = [0, 0] # starting position
end = [len(maze)-1, len(maze[0])-1] # ending position
cost = 1 # cost per movement

move = [[-1, 0 ], # go up
        [ 0, -1], # go left
        [ 1, 0 ], # go down
        [ 0, 1 ]] # go right


### 1. make your own heuristic
heuristic = [[0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0]]


### 2. finish the A* search funciton below
def search(maze, start, end, cost, heuristic):

    return 

